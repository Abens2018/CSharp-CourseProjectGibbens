﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace section2Lab_GibbensProject
{
    public partial class frmTest2 : Form
    {
        static void Main()
        {
            Application.Run(new frmTest2());
        }
        public frmTest2()
        {
            InitializeComponent();
            btnModulusDo.Enabled = false;
            btnFactorialDo.Enabled = false;
            btnFibonacciDo.Enabled = false;
        }
        private bool ErrorsMods(string szNum1, string szNum2)
        {
            if (!int.TryParse(szNum1, out _) || !int.TryParse(szNum2, out _))
            {
                lblMessage.Text = "The text boxes need to have an interger";
                return false;
            } else
            {
                int iNum1 = Convert.ToInt32(szNum1);
                int iNum2 = Convert.ToInt32(szNum2);
                if (iNum2 == 0)
                {
                    lblMessage.Text = "You cannot divide by zero";
                    return false;
                }
                else
                {
                    if (iNum1 >= iNum2)
                    {
                        return true;
                    }
                    else
                    {
                        lblMessage.Text = "Number 2 needs to be less then number one";
                        return false;
                    }
                }
            }
        }

        private bool ErrorsFact(string szNum1)
        {
            if (!int.TryParse(szNum1, out _))
            {
                lblMessage.Text = "The text box needs to have an interger";
                return false;
            }
            else
            {
                int iNum1 = Convert.ToInt32(szNum1);
                if (iNum1 > 15)
                {
                    lblMessage.Text = "The Factorial cannot be greater then 15";
                    return false;
                } else
                {
                    return true;
                }
            }
        }
        private bool ErrorsFib(string szNum1)
        {
            if (!int.TryParse(szNum1, out _))
            {
                lblMessage.Text = "The text box needs to have an interger";
                return false;
            }
            else
            {
                int iNum1 = Convert.ToInt32(szNum1);
                if (iNum1 > 45)
                {
                    lblMessage.Text = "The number cannot be greater then 45";
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you for useing this program!", "Closing Box");
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblMessage.Text = " ";
        }

        private void btnModulusShow_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "Insert two numbers and you will recieve the first number divided by the" +
                " second alongside the remainder.";
            lblNum2.Visible = true;
            txtNum2.Visible = true; 
            btnModulusDo.Enabled = true;
            btnFactorialDo.Enabled = false;
            btnFibonacciDo.Enabled = false;
        }

        private void btnFactorialShow_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "Insert a number and you will recieve the number multiplied by every number" +
                " before it.";
            lblNum2.Visible = false;
            txtNum2.Visible = false;
            btnModulusDo.Enabled = false;
            btnFactorialDo.Enabled = true;
            btnFibonacciDo.Enabled = false;
        }

        private void btnFibonacciShow_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "Insert a number and you will recieve That number in the fibonacci sequence.";
            lblNum2.Visible = false;
            txtNum2.Visible = false;
            btnModulusDo.Enabled = false;
            btnFactorialDo.Enabled = false;
            btnFibonacciDo.Enabled = true;
        }

        private void btnModulusDo_Click(object sender, EventArgs e)
        {
            int iNum1 = 0;
            int iNum2 = 0;
            int mult = 0;
            string szNum1 = " ";
            string szNum2 = " ";
            string working = " ";
            string szquotiant = " ";


            szNum1 = txtNum1.Text;
            szNum2 = txtNum2.Text;
            
            lblMessage.Text = szNum1 + " divided by " + szNum2 + " equals ";


            bool noError = ErrorsMods(szNum1, szNum2);
            if (noError == true)
            {

                iNum1 = Convert.ToInt32(szNum1);
                iNum2 = Convert.ToInt32(szNum2);
                int digitCount = iNum1.ToString().Length;
                for (int i = 0; i < digitCount; i++)
                {

                    int count = 0;
                    mult = iNum2;
                    char digit = iNum1.ToString()[i];
                    working = working + digit;
                    int workingNum = Convert.ToInt32(working);
                    while (mult <= workingNum)
                    {
                        count++;
                        mult += iNum2;
                    }
                    mult -= iNum2;
                    workingNum = workingNum - mult;
                    working = workingNum.ToString();
                    szquotiant += count;
                    lblMessage.Text = lblMessage.Text + count;
                }
                mult = 0;
                int iquotiant = Convert.ToInt32(szquotiant);
                for (int j = 1; j <= iquotiant; j++)
                {
                    mult += iNum2;
                }
                int remainder = 0;
                remainder = iNum1 - mult;
                if (remainder > 0)
                {
                    lblMessage.Text = lblMessage.Text + ", With a remainder of " + remainder;
                }
            }
        }

        private void btnFactorialDo_Click(object sender, EventArgs e)
        {
            int iNum1 = 0;
            string szNum1 = " ";

            szNum1 = txtNum1.Text;
            bool noError = ErrorsFact(szNum1);
            if (noError == true)
            {
                iNum1 = Convert.ToInt32(szNum1);

                if (iNum1 == 0 || iNum1 == 1)
                {
                    lblMessage.Text = "The answer to " + iNum1 + "! is 1";
                }
                else
                {
                    int f = 1;
                    for (int i = 1; i <= iNum1; i++)
                    {
                        f *= i;
                    }
                    lblMessage.Text = "The answer to " + iNum1 + "! is " + f;
                }
            }
        }

        private void btnFibonacciDo_Click(object sender, EventArgs e)
        {
            int iNum1 = 0;
            string szNum1 = " ";

            szNum1 = txtNum1.Text;
            bool noError = ErrorsFib(szNum1);
            if (noError == true)
            {
                iNum1 = Convert.ToInt32(szNum1);

                if (iNum1 == 0)
                {
                    lblMessage.Text = "Fibonacci(0) = 0";
                }
                else if (iNum1 == 1)
                {
                    lblMessage.Text = "Fibonacci(1) = 1";
                }
                else
                {
                    int j = 1;
                    int k = 0;
                    int fib = 0;
                    int a = j;
                    int b = k;

                    for (int i = 0; i < iNum1; i++)
                    {
                        a = j;
                        b = k;
                        fib = j + k;
                        j = k;
                        k = fib;
                    }
                    lblMessage.Text = "Fibonacci(" + iNum1 + ") = Fibonacci(" + (iNum1 - 1) +
                        ") + Fibonacci(" + (iNum1 - 2) + ") = " + b + " + " + a + " = " + fib;

                }
            }
        }
    }
}
