﻿namespace section2Lab_GibbensProject
{
    partial class frmTest2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFactorialShow = new System.Windows.Forms.Button();
            this.btnFactorialDo = new System.Windows.Forms.Button();
            this.btnFibonacciDo = new System.Windows.Forms.Button();
            this.btnFibonacciShow = new System.Windows.Forms.Button();
            this.btnModulusDo = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.lblModulus = new System.Windows.Forms.Label();
            this.lblFactorial = new System.Windows.Forms.Label();
            this.lblFibonacci = new System.Windows.Forms.Label();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.btnModulusShow = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnFactorialShow
            // 
            this.btnFactorialShow.BackColor = System.Drawing.Color.LightBlue;
            this.btnFactorialShow.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.btnFactorialShow.Location = new System.Drawing.Point(176, 196);
            this.btnFactorialShow.Name = "btnFactorialShow";
            this.btnFactorialShow.Size = new System.Drawing.Size(157, 48);
            this.btnFactorialShow.TabIndex = 2;
            this.btnFactorialShow.Text = "Show";
            this.btnFactorialShow.UseVisualStyleBackColor = false;
            this.btnFactorialShow.Click += new System.EventHandler(this.btnFactorialShow_Click);
            // 
            // btnFactorialDo
            // 
            this.btnFactorialDo.BackColor = System.Drawing.Color.LightBlue;
            this.btnFactorialDo.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.btnFactorialDo.Location = new System.Drawing.Point(176, 250);
            this.btnFactorialDo.Name = "btnFactorialDo";
            this.btnFactorialDo.Size = new System.Drawing.Size(162, 48);
            this.btnFactorialDo.TabIndex = 3;
            this.btnFactorialDo.Text = "Do F&act";
            this.btnFactorialDo.UseVisualStyleBackColor = false;
            this.btnFactorialDo.Click += new System.EventHandler(this.btnFactorialDo_Click);
            // 
            // btnFibonacciDo
            // 
            this.btnFibonacciDo.BackColor = System.Drawing.Color.LightBlue;
            this.btnFibonacciDo.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.btnFibonacciDo.Location = new System.Drawing.Point(344, 250);
            this.btnFibonacciDo.Name = "btnFibonacciDo";
            this.btnFibonacciDo.Size = new System.Drawing.Size(140, 48);
            this.btnFibonacciDo.TabIndex = 5;
            this.btnFibonacciDo.Text = "Do F&ib";
            this.btnFibonacciDo.UseVisualStyleBackColor = false;
            this.btnFibonacciDo.Click += new System.EventHandler(this.btnFibonacciDo_Click);
            // 
            // btnFibonacciShow
            // 
            this.btnFibonacciShow.BackColor = System.Drawing.Color.LightBlue;
            this.btnFibonacciShow.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.btnFibonacciShow.Location = new System.Drawing.Point(344, 196);
            this.btnFibonacciShow.Name = "btnFibonacciShow";
            this.btnFibonacciShow.Size = new System.Drawing.Size(140, 48);
            this.btnFibonacciShow.TabIndex = 4;
            this.btnFibonacciShow.Text = "Show";
            this.btnFibonacciShow.UseVisualStyleBackColor = false;
            this.btnFibonacciShow.Click += new System.EventHandler(this.btnFibonacciShow_Click);
            // 
            // btnModulusDo
            // 
            this.btnModulusDo.BackColor = System.Drawing.Color.LightBlue;
            this.btnModulusDo.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.btnModulusDo.Location = new System.Drawing.Point(12, 250);
            this.btnModulusDo.Name = "btnModulusDo";
            this.btnModulusDo.Size = new System.Drawing.Size(158, 48);
            this.btnModulusDo.TabIndex = 1;
            this.btnModulusDo.Text = "Do &Mod";
            this.btnModulusDo.UseVisualStyleBackColor = false;
            this.btnModulusDo.Click += new System.EventHandler(this.btnModulusDo_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.LightBlue;
            this.btnClear.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.btnClear.Location = new System.Drawing.Point(12, 304);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(226, 48);
            this.btnClear.TabIndex = 6;
            this.btnClear.TabStop = false;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.LightBlue;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.btnExit.Location = new System.Drawing.Point(252, 304);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(232, 48);
            this.btnExit.TabIndex = 8;
            this.btnExit.TabStop = false;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.BackColor = System.Drawing.Color.AliceBlue;
            this.lblMessage.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(17, 371);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(467, 190);
            this.lblMessage.TabIndex = 9;
            this.lblMessage.Text = "The clear button clears this box";
            // 
            // lblModulus
            // 
            this.lblModulus.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblModulus.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.lblModulus.Location = new System.Drawing.Point(12, 135);
            this.lblModulus.Name = "lblModulus";
            this.lblModulus.Size = new System.Drawing.Size(158, 48);
            this.lblModulus.TabIndex = 10;
            this.lblModulus.Text = "Modulus ";
            this.lblModulus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFactorial
            // 
            this.lblFactorial.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblFactorial.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.lblFactorial.Location = new System.Drawing.Point(180, 135);
            this.lblFactorial.Name = "lblFactorial";
            this.lblFactorial.Size = new System.Drawing.Size(153, 48);
            this.lblFactorial.TabIndex = 11;
            this.lblFactorial.Text = "Factorial";
            this.lblFactorial.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFibonacci
            // 
            this.lblFibonacci.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblFibonacci.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.lblFibonacci.Location = new System.Drawing.Point(339, 135);
            this.lblFibonacci.Name = "lblFibonacci";
            this.lblFibonacci.Size = new System.Drawing.Size(162, 48);
            this.lblFibonacci.TabIndex = 12;
            this.lblFibonacci.Text = "Fibonacci";
            this.lblFibonacci.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum1
            // 
            this.lblNum1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblNum1.Font = new System.Drawing.Font("Courier New", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum1.Location = new System.Drawing.Point(12, 9);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(125, 48);
            this.lblNum1.TabIndex = 13;
            this.lblNum1.Text = "Number 1";
            // 
            // lblNum2
            // 
            this.lblNum2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblNum2.Font = new System.Drawing.Font("Courier New", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum2.Location = new System.Drawing.Point(12, 73);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(125, 48);
            this.lblNum2.TabIndex = 14;
            this.lblNum2.Text = "Number 2";
            // 
            // txtNum1
            // 
            this.txtNum1.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.txtNum1.Location = new System.Drawing.Point(176, 9);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(308, 34);
            this.txtNum1.TabIndex = 15;
            this.txtNum1.TabStop = false;
            this.txtNum1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNum2
            // 
            this.txtNum2.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.txtNum2.Location = new System.Drawing.Point(176, 73);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(308, 34);
            this.txtNum2.TabIndex = 16;
            this.txtNum2.TabStop = false;
            this.txtNum2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnModulusShow
            // 
            this.btnModulusShow.BackColor = System.Drawing.Color.LightBlue;
            this.btnModulusShow.Font = new System.Drawing.Font("Courier New", 13.8F);
            this.btnModulusShow.Location = new System.Drawing.Point(12, 196);
            this.btnModulusShow.Name = "btnModulusShow";
            this.btnModulusShow.Size = new System.Drawing.Size(157, 48);
            this.btnModulusShow.TabIndex = 0;
            this.btnModulusShow.Text = "Show";
            this.btnModulusShow.UseVisualStyleBackColor = false;
            this.btnModulusShow.Click += new System.EventHandler(this.btnModulusShow_Click);
            // 
            // frmTest2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(496, 570);
            this.Controls.Add(this.btnModulusShow);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.lblFibonacci);
            this.Controls.Add(this.lblFactorial);
            this.Controls.Add(this.lblModulus);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnModulusDo);
            this.Controls.Add(this.btnFibonacciShow);
            this.Controls.Add(this.btnFibonacciDo);
            this.Controls.Add(this.btnFactorialDo);
            this.Controls.Add(this.btnFactorialShow);
            this.Name = "frmTest2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmTest2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnFactorialShow;
        private System.Windows.Forms.Button btnFactorialDo;
        private System.Windows.Forms.Button btnFibonacciDo;
        private System.Windows.Forms.Button btnFibonacciShow;
        private System.Windows.Forms.Button btnModulusDo;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Label lblModulus;
        private System.Windows.Forms.Label lblFactorial;
        private System.Windows.Forms.Label lblFibonacci;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Button btnModulusShow;
    }
}