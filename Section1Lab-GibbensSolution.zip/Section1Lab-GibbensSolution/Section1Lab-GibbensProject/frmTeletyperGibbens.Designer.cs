﻿namespace Section1Lab_GibbensProject
{
    partial class frmTeletyperGibbens
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBlankSpace = new System.Windows.Forms.Button();
            this.btnComma = new System.Windows.Forms.Button();
            this.btnPeriod = new System.Windows.Forms.Button();
            this.btnLetterK = new System.Windows.Forms.Button();
            this.btnLetterD = new System.Windows.Forms.Button();
            this.btnLetterR = new System.Windows.Forms.Button();
            this.btnDigit0 = new System.Windows.Forms.Button();
            this.btnDigit6 = new System.Windows.Forms.Button();
            this.btnDigit5 = new System.Windows.Forms.Button();
            this.btnDigit4 = new System.Windows.Forms.Button();
            this.btnDigit3 = new System.Windows.Forms.Button();
            this.btnDigit2 = new System.Windows.Forms.Button();
            this.btnDigit1 = new System.Windows.Forms.Button();
            this.btnDigit9 = new System.Windows.Forms.Button();
            this.btnDigit8 = new System.Windows.Forms.Button();
            this.btnDigit7 = new System.Windows.Forms.Button();
            this.btnLetterL = new System.Windows.Forms.Button();
            this.btnLetterH = new System.Windows.Forms.Button();
            this.btnLetterI = new System.Windows.Forms.Button();
            this.btnLetterJ = new System.Windows.Forms.Button();
            this.btnLetterN = new System.Windows.Forms.Button();
            this.btnLetterM = new System.Windows.Forms.Button();
            this.btnLetterS = new System.Windows.Forms.Button();
            this.btnLetterO = new System.Windows.Forms.Button();
            this.btnLetterP = new System.Windows.Forms.Button();
            this.btnLetterG = new System.Windows.Forms.Button();
            this.btnLetterQ = new System.Windows.Forms.Button();
            this.btnLetterC = new System.Windows.Forms.Button();
            this.btnLetterB = new System.Windows.Forms.Button();
            this.btnLetterA = new System.Windows.Forms.Button();
            this.btnLetterE = new System.Windows.Forms.Button();
            this.btnLetterF = new System.Windows.Forms.Button();
            this.btnLetterT = new System.Windows.Forms.Button();
            this.btnLetterY = new System.Windows.Forms.Button();
            this.btnLetterV = new System.Windows.Forms.Button();
            this.btnLetterW = new System.Windows.Forms.Button();
            this.btnLetterZ = new System.Windows.Forms.Button();
            this.btnLetterX = new System.Windows.Forms.Button();
            this.btnLetterU = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtMain = new System.Windows.Forms.TextBox();
            this.lblMain = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnBlankSpace
            // 
            this.btnBlankSpace.BackColor = System.Drawing.Color.Black;
            this.btnBlankSpace.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBlankSpace.ForeColor = System.Drawing.Color.White;
            this.btnBlankSpace.Location = new System.Drawing.Point(146, 82);
            this.btnBlankSpace.Name = "btnBlankSpace";
            this.btnBlankSpace.Size = new System.Drawing.Size(642, 58);
            this.btnBlankSpace.TabIndex = 2;
            this.btnBlankSpace.TabStop = false;
            this.btnBlankSpace.Text = "Blank";
            this.btnBlankSpace.UseVisualStyleBackColor = false;
            this.btnBlankSpace.Click += new System.EventHandler(this.btnBlankSpace_Click);
            // 
            // btnComma
            // 
            this.btnComma.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnComma.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComma.Location = new System.Drawing.Point(65, 82);
            this.btnComma.Name = "btnComma";
            this.btnComma.Size = new System.Drawing.Size(75, 58);
            this.btnComma.TabIndex = 3;
            this.btnComma.TabStop = false;
            this.btnComma.Text = ",";
            this.btnComma.UseVisualStyleBackColor = false;
            this.btnComma.Click += new System.EventHandler(this.btnComma_Click);
            // 
            // btnPeriod
            // 
            this.btnPeriod.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnPeriod.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPeriod.Location = new System.Drawing.Point(794, 82);
            this.btnPeriod.Name = "btnPeriod";
            this.btnPeriod.Size = new System.Drawing.Size(75, 58);
            this.btnPeriod.TabIndex = 4;
            this.btnPeriod.TabStop = false;
            this.btnPeriod.Text = ".";
            this.btnPeriod.UseVisualStyleBackColor = false;
            this.btnPeriod.Click += new System.EventHandler(this.btnPeriod_Click);
            // 
            // btnLetterK
            // 
            this.btnLetterK.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterK.Location = new System.Drawing.Point(227, 146);
            this.btnLetterK.Name = "btnLetterK";
            this.btnLetterK.Size = new System.Drawing.Size(75, 58);
            this.btnLetterK.TabIndex = 5;
            this.btnLetterK.TabStop = false;
            this.btnLetterK.Text = "K";
            this.btnLetterK.UseVisualStyleBackColor = false;
            this.btnLetterK.Click += new System.EventHandler(this.btnLetterK_Click);
            // 
            // btnLetterD
            // 
            this.btnLetterD.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterD.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterD.Location = new System.Drawing.Point(227, 210);
            this.btnLetterD.Name = "btnLetterD";
            this.btnLetterD.Size = new System.Drawing.Size(75, 58);
            this.btnLetterD.TabIndex = 6;
            this.btnLetterD.TabStop = false;
            this.btnLetterD.Text = "D";
            this.btnLetterD.UseVisualStyleBackColor = false;
            this.btnLetterD.Click += new System.EventHandler(this.btnLetterD_Click);
            // 
            // btnLetterR
            // 
            this.btnLetterR.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterR.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterR.Location = new System.Drawing.Point(227, 274);
            this.btnLetterR.Name = "btnLetterR";
            this.btnLetterR.Size = new System.Drawing.Size(75, 58);
            this.btnLetterR.TabIndex = 7;
            this.btnLetterR.TabStop = false;
            this.btnLetterR.Text = "R";
            this.btnLetterR.UseVisualStyleBackColor = false;
            this.btnLetterR.Click += new System.EventHandler(this.btnLetterR_Click);
            // 
            // btnDigit0
            // 
            this.btnDigit0.BackColor = System.Drawing.Color.SlateGray;
            this.btnDigit0.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDigit0.Location = new System.Drawing.Point(65, 418);
            this.btnDigit0.Name = "btnDigit0";
            this.btnDigit0.Size = new System.Drawing.Size(75, 58);
            this.btnDigit0.TabIndex = 8;
            this.btnDigit0.TabStop = false;
            this.btnDigit0.Text = "0";
            this.btnDigit0.UseVisualStyleBackColor = false;
            this.btnDigit0.Click += new System.EventHandler(this.btnDigit0_Click);
            // 
            // btnDigit6
            // 
            this.btnDigit6.BackColor = System.Drawing.Color.SlateGray;
            this.btnDigit6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDigit6.Location = new System.Drawing.Point(551, 418);
            this.btnDigit6.Name = "btnDigit6";
            this.btnDigit6.Size = new System.Drawing.Size(75, 58);
            this.btnDigit6.TabIndex = 9;
            this.btnDigit6.TabStop = false;
            this.btnDigit6.Text = "6";
            this.btnDigit6.UseVisualStyleBackColor = false;
            this.btnDigit6.Click += new System.EventHandler(this.btnDigit6_Click);
            // 
            // btnDigit5
            // 
            this.btnDigit5.BackColor = System.Drawing.Color.SlateGray;
            this.btnDigit5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDigit5.Location = new System.Drawing.Point(470, 418);
            this.btnDigit5.Name = "btnDigit5";
            this.btnDigit5.Size = new System.Drawing.Size(75, 58);
            this.btnDigit5.TabIndex = 10;
            this.btnDigit5.TabStop = false;
            this.btnDigit5.Text = "5";
            this.btnDigit5.UseVisualStyleBackColor = false;
            this.btnDigit5.Click += new System.EventHandler(this.btnDigit5_Click);
            // 
            // btnDigit4
            // 
            this.btnDigit4.BackColor = System.Drawing.Color.SlateGray;
            this.btnDigit4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDigit4.Location = new System.Drawing.Point(389, 418);
            this.btnDigit4.Name = "btnDigit4";
            this.btnDigit4.Size = new System.Drawing.Size(75, 58);
            this.btnDigit4.TabIndex = 11;
            this.btnDigit4.TabStop = false;
            this.btnDigit4.Text = "4";
            this.btnDigit4.UseVisualStyleBackColor = false;
            this.btnDigit4.Click += new System.EventHandler(this.btnDigit4_Click);
            // 
            // btnDigit3
            // 
            this.btnDigit3.BackColor = System.Drawing.Color.SlateGray;
            this.btnDigit3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDigit3.Location = new System.Drawing.Point(308, 418);
            this.btnDigit3.Name = "btnDigit3";
            this.btnDigit3.Size = new System.Drawing.Size(75, 58);
            this.btnDigit3.TabIndex = 12;
            this.btnDigit3.TabStop = false;
            this.btnDigit3.Text = "3";
            this.btnDigit3.UseVisualStyleBackColor = false;
            this.btnDigit3.Click += new System.EventHandler(this.btnDigit3_Click);
            // 
            // btnDigit2
            // 
            this.btnDigit2.BackColor = System.Drawing.Color.SlateGray;
            this.btnDigit2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDigit2.Location = new System.Drawing.Point(227, 418);
            this.btnDigit2.Name = "btnDigit2";
            this.btnDigit2.Size = new System.Drawing.Size(75, 58);
            this.btnDigit2.TabIndex = 13;
            this.btnDigit2.TabStop = false;
            this.btnDigit2.Text = "2";
            this.btnDigit2.UseVisualStyleBackColor = false;
            this.btnDigit2.Click += new System.EventHandler(this.btnDigit2_Click);
            // 
            // btnDigit1
            // 
            this.btnDigit1.BackColor = System.Drawing.Color.SlateGray;
            this.btnDigit1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDigit1.Location = new System.Drawing.Point(146, 418);
            this.btnDigit1.Name = "btnDigit1";
            this.btnDigit1.Size = new System.Drawing.Size(75, 58);
            this.btnDigit1.TabIndex = 14;
            this.btnDigit1.TabStop = false;
            this.btnDigit1.Text = "1";
            this.btnDigit1.UseVisualStyleBackColor = false;
            this.btnDigit1.Click += new System.EventHandler(this.btnDigit1_Click);
            // 
            // btnDigit9
            // 
            this.btnDigit9.BackColor = System.Drawing.Color.SlateGray;
            this.btnDigit9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDigit9.Location = new System.Drawing.Point(794, 418);
            this.btnDigit9.Name = "btnDigit9";
            this.btnDigit9.Size = new System.Drawing.Size(75, 58);
            this.btnDigit9.TabIndex = 15;
            this.btnDigit9.TabStop = false;
            this.btnDigit9.Text = "f";
            this.btnDigit9.UseVisualStyleBackColor = false;
            this.btnDigit9.Click += new System.EventHandler(this.btnDigit9_Click);
            // 
            // btnDigit8
            // 
            this.btnDigit8.BackColor = System.Drawing.Color.SlateGray;
            this.btnDigit8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDigit8.Location = new System.Drawing.Point(713, 418);
            this.btnDigit8.Name = "btnDigit8";
            this.btnDigit8.Size = new System.Drawing.Size(75, 58);
            this.btnDigit8.TabIndex = 16;
            this.btnDigit8.TabStop = false;
            this.btnDigit8.Text = "8";
            this.btnDigit8.UseVisualStyleBackColor = false;
            this.btnDigit8.Click += new System.EventHandler(this.btnDigit8_Click);
            // 
            // btnDigit7
            // 
            this.btnDigit7.BackColor = System.Drawing.Color.SlateGray;
            this.btnDigit7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDigit7.Location = new System.Drawing.Point(632, 418);
            this.btnDigit7.Name = "btnDigit7";
            this.btnDigit7.Size = new System.Drawing.Size(75, 58);
            this.btnDigit7.TabIndex = 17;
            this.btnDigit7.TabStop = false;
            this.btnDigit7.Text = "7";
            this.btnDigit7.UseVisualStyleBackColor = false;
            this.btnDigit7.Click += new System.EventHandler(this.btnDigit7_Click);
            // 
            // btnLetterL
            // 
            this.btnLetterL.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterL.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterL.Location = new System.Drawing.Point(551, 146);
            this.btnLetterL.Name = "btnLetterL";
            this.btnLetterL.Size = new System.Drawing.Size(75, 58);
            this.btnLetterL.TabIndex = 21;
            this.btnLetterL.TabStop = false;
            this.btnLetterL.Text = "L";
            this.btnLetterL.UseVisualStyleBackColor = false;
            this.btnLetterL.Click += new System.EventHandler(this.btnLetterL_Click);
            // 
            // btnLetterH
            // 
            this.btnLetterH.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterH.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterH.Location = new System.Drawing.Point(470, 146);
            this.btnLetterH.Name = "btnLetterH";
            this.btnLetterH.Size = new System.Drawing.Size(75, 58);
            this.btnLetterH.TabIndex = 22;
            this.btnLetterH.TabStop = false;
            this.btnLetterH.Text = "H";
            this.btnLetterH.UseVisualStyleBackColor = false;
            this.btnLetterH.Click += new System.EventHandler(this.btnLetterH_Click);
            // 
            // btnLetterI
            // 
            this.btnLetterI.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterI.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterI.Location = new System.Drawing.Point(389, 146);
            this.btnLetterI.Name = "btnLetterI";
            this.btnLetterI.Size = new System.Drawing.Size(75, 58);
            this.btnLetterI.TabIndex = 23;
            this.btnLetterI.TabStop = false;
            this.btnLetterI.Text = "I";
            this.btnLetterI.UseVisualStyleBackColor = false;
            this.btnLetterI.Click += new System.EventHandler(this.btnLetterI_Click);
            // 
            // btnLetterJ
            // 
            this.btnLetterJ.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterJ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterJ.Location = new System.Drawing.Point(308, 146);
            this.btnLetterJ.Name = "btnLetterJ";
            this.btnLetterJ.Size = new System.Drawing.Size(75, 58);
            this.btnLetterJ.TabIndex = 24;
            this.btnLetterJ.TabStop = false;
            this.btnLetterJ.Text = "J";
            this.btnLetterJ.UseVisualStyleBackColor = false;
            this.btnLetterJ.Click += new System.EventHandler(this.btnLetterJ_Click);
            // 
            // btnLetterN
            // 
            this.btnLetterN.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterN.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterN.Location = new System.Drawing.Point(713, 146);
            this.btnLetterN.Name = "btnLetterN";
            this.btnLetterN.Size = new System.Drawing.Size(75, 58);
            this.btnLetterN.TabIndex = 25;
            this.btnLetterN.TabStop = false;
            this.btnLetterN.Text = "N";
            this.btnLetterN.UseVisualStyleBackColor = false;
            this.btnLetterN.Click += new System.EventHandler(this.btnLetterN_Click);
            // 
            // btnLetterM
            // 
            this.btnLetterM.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterM.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterM.Location = new System.Drawing.Point(632, 146);
            this.btnLetterM.Name = "btnLetterM";
            this.btnLetterM.Size = new System.Drawing.Size(75, 58);
            this.btnLetterM.TabIndex = 26;
            this.btnLetterM.TabStop = false;
            this.btnLetterM.Text = "M";
            this.btnLetterM.UseVisualStyleBackColor = false;
            this.btnLetterM.Click += new System.EventHandler(this.btnLetterM_Click);
            // 
            // btnLetterS
            // 
            this.btnLetterS.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterS.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterS.Location = new System.Drawing.Point(551, 274);
            this.btnLetterS.Name = "btnLetterS";
            this.btnLetterS.Size = new System.Drawing.Size(75, 58);
            this.btnLetterS.TabIndex = 27;
            this.btnLetterS.TabStop = false;
            this.btnLetterS.Text = "S";
            this.btnLetterS.UseVisualStyleBackColor = false;
            this.btnLetterS.Click += new System.EventHandler(this.btnLetterS_Click);
            // 
            // btnLetterO
            // 
            this.btnLetterO.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterO.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterO.Location = new System.Drawing.Point(470, 274);
            this.btnLetterO.Name = "btnLetterO";
            this.btnLetterO.Size = new System.Drawing.Size(75, 58);
            this.btnLetterO.TabIndex = 28;
            this.btnLetterO.TabStop = false;
            this.btnLetterO.Text = "O";
            this.btnLetterO.UseVisualStyleBackColor = false;
            this.btnLetterO.Click += new System.EventHandler(this.btnLetterO_Click);
            // 
            // btnLetterP
            // 
            this.btnLetterP.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterP.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterP.Location = new System.Drawing.Point(389, 274);
            this.btnLetterP.Name = "btnLetterP";
            this.btnLetterP.Size = new System.Drawing.Size(75, 58);
            this.btnLetterP.TabIndex = 29;
            this.btnLetterP.TabStop = false;
            this.btnLetterP.Text = "P";
            this.btnLetterP.UseVisualStyleBackColor = false;
            this.btnLetterP.Click += new System.EventHandler(this.btnLetterP_Click);
            // 
            // btnLetterG
            // 
            this.btnLetterG.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterG.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterG.Location = new System.Drawing.Point(713, 210);
            this.btnLetterG.Name = "btnLetterG";
            this.btnLetterG.Size = new System.Drawing.Size(75, 58);
            this.btnLetterG.TabIndex = 30;
            this.btnLetterG.TabStop = false;
            this.btnLetterG.Text = "G";
            this.btnLetterG.UseVisualStyleBackColor = false;
            this.btnLetterG.Click += new System.EventHandler(this.btnLetterG_Click);
            // 
            // btnLetterQ
            // 
            this.btnLetterQ.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterQ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterQ.Location = new System.Drawing.Point(308, 274);
            this.btnLetterQ.Name = "btnLetterQ";
            this.btnLetterQ.Size = new System.Drawing.Size(75, 58);
            this.btnLetterQ.TabIndex = 31;
            this.btnLetterQ.TabStop = false;
            this.btnLetterQ.Text = "Q";
            this.btnLetterQ.UseVisualStyleBackColor = false;
            this.btnLetterQ.Click += new System.EventHandler(this.btnLetterQ_Click);
            // 
            // btnLetterC
            // 
            this.btnLetterC.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterC.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterC.Location = new System.Drawing.Point(308, 210);
            this.btnLetterC.Name = "btnLetterC";
            this.btnLetterC.Size = new System.Drawing.Size(75, 58);
            this.btnLetterC.TabIndex = 32;
            this.btnLetterC.TabStop = false;
            this.btnLetterC.Text = "C";
            this.btnLetterC.UseVisualStyleBackColor = false;
            this.btnLetterC.Click += new System.EventHandler(this.btnLetterC_Click);
            // 
            // btnLetterB
            // 
            this.btnLetterB.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterB.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterB.Location = new System.Drawing.Point(389, 210);
            this.btnLetterB.Name = "btnLetterB";
            this.btnLetterB.Size = new System.Drawing.Size(75, 58);
            this.btnLetterB.TabIndex = 33;
            this.btnLetterB.TabStop = false;
            this.btnLetterB.Text = "B";
            this.btnLetterB.UseVisualStyleBackColor = false;
            this.btnLetterB.Click += new System.EventHandler(this.btnLetterB_Click);
            // 
            // btnLetterA
            // 
            this.btnLetterA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterA.Location = new System.Drawing.Point(470, 210);
            this.btnLetterA.Name = "btnLetterA";
            this.btnLetterA.Size = new System.Drawing.Size(75, 58);
            this.btnLetterA.TabIndex = 34;
            this.btnLetterA.TabStop = false;
            this.btnLetterA.Text = "A";
            this.btnLetterA.UseVisualStyleBackColor = false;
            this.btnLetterA.Click += new System.EventHandler(this.btnLetterA_Click);
            // 
            // btnLetterE
            // 
            this.btnLetterE.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterE.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterE.Location = new System.Drawing.Point(551, 210);
            this.btnLetterE.Name = "btnLetterE";
            this.btnLetterE.Size = new System.Drawing.Size(75, 58);
            this.btnLetterE.TabIndex = 35;
            this.btnLetterE.TabStop = false;
            this.btnLetterE.Text = "E";
            this.btnLetterE.UseVisualStyleBackColor = false;
            this.btnLetterE.Click += new System.EventHandler(this.btnLetterE_Click);
            // 
            // btnLetterF
            // 
            this.btnLetterF.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterF.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterF.Location = new System.Drawing.Point(632, 210);
            this.btnLetterF.Name = "btnLetterF";
            this.btnLetterF.Size = new System.Drawing.Size(75, 58);
            this.btnLetterF.TabIndex = 36;
            this.btnLetterF.TabStop = false;
            this.btnLetterF.Text = "F";
            this.btnLetterF.UseVisualStyleBackColor = false;
            this.btnLetterF.Click += new System.EventHandler(this.btnLetterF_Click);
            // 
            // btnLetterT
            // 
            this.btnLetterT.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterT.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterT.Location = new System.Drawing.Point(632, 274);
            this.btnLetterT.Name = "btnLetterT";
            this.btnLetterT.Size = new System.Drawing.Size(75, 58);
            this.btnLetterT.TabIndex = 37;
            this.btnLetterT.TabStop = false;
            this.btnLetterT.Text = "T";
            this.btnLetterT.UseVisualStyleBackColor = false;
            this.btnLetterT.Click += new System.EventHandler(this.btnLetterT_Click);
            // 
            // btnLetterY
            // 
            this.btnLetterY.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterY.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterY.Location = new System.Drawing.Point(551, 338);
            this.btnLetterY.Name = "btnLetterY";
            this.btnLetterY.Size = new System.Drawing.Size(75, 58);
            this.btnLetterY.TabIndex = 38;
            this.btnLetterY.TabStop = false;
            this.btnLetterY.Text = "Y";
            this.btnLetterY.UseVisualStyleBackColor = false;
            this.btnLetterY.Click += new System.EventHandler(this.btnLetterY_Click);
            // 
            // btnLetterV
            // 
            this.btnLetterV.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterV.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterV.Location = new System.Drawing.Point(308, 338);
            this.btnLetterV.Name = "btnLetterV";
            this.btnLetterV.Size = new System.Drawing.Size(75, 58);
            this.btnLetterV.TabIndex = 39;
            this.btnLetterV.TabStop = false;
            this.btnLetterV.Text = "V";
            this.btnLetterV.UseVisualStyleBackColor = false;
            this.btnLetterV.Click += new System.EventHandler(this.btnLetterV_Click);
            // 
            // btnLetterW
            // 
            this.btnLetterW.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterW.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterW.Location = new System.Drawing.Point(389, 338);
            this.btnLetterW.Name = "btnLetterW";
            this.btnLetterW.Size = new System.Drawing.Size(75, 58);
            this.btnLetterW.TabIndex = 40;
            this.btnLetterW.TabStop = false;
            this.btnLetterW.Text = "W";
            this.btnLetterW.UseVisualStyleBackColor = false;
            this.btnLetterW.Click += new System.EventHandler(this.btnLetterW_Click);
            // 
            // btnLetterZ
            // 
            this.btnLetterZ.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterZ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterZ.Location = new System.Drawing.Point(632, 338);
            this.btnLetterZ.Name = "btnLetterZ";
            this.btnLetterZ.Size = new System.Drawing.Size(75, 58);
            this.btnLetterZ.TabIndex = 41;
            this.btnLetterZ.TabStop = false;
            this.btnLetterZ.Text = "Z";
            this.btnLetterZ.UseVisualStyleBackColor = false;
            this.btnLetterZ.Click += new System.EventHandler(this.btnLetterZ_Click);
            // 
            // btnLetterX
            // 
            this.btnLetterX.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterX.Location = new System.Drawing.Point(470, 338);
            this.btnLetterX.Name = "btnLetterX";
            this.btnLetterX.Size = new System.Drawing.Size(75, 58);
            this.btnLetterX.TabIndex = 42;
            this.btnLetterX.TabStop = false;
            this.btnLetterX.Text = "X";
            this.btnLetterX.UseVisualStyleBackColor = false;
            this.btnLetterX.Click += new System.EventHandler(this.btnLetterX_Click);
            // 
            // btnLetterU
            // 
            this.btnLetterU.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLetterU.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetterU.Location = new System.Drawing.Point(713, 274);
            this.btnLetterU.Name = "btnLetterU";
            this.btnLetterU.Size = new System.Drawing.Size(75, 58);
            this.btnLetterU.TabIndex = 43;
            this.btnLetterU.TabStop = false;
            this.btnLetterU.Text = "U";
            this.btnLetterU.UseVisualStyleBackColor = false;
            this.btnLetterU.Click += new System.EventHandler(this.btnLetterU_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(794, 146);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 250);
            this.btnExit.TabIndex = 20;
            this.btnExit.TabStop = false;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnClear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(65, 146);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 250);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSend
            // 
            this.btnSend.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnSend.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSend.Location = new System.Drawing.Point(146, 146);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 250);
            this.btnSend.TabIndex = 2;
            this.btnSend.Text = "&Send";
            this.btnSend.UseVisualStyleBackColor = false;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtMain
            // 
            this.txtMain.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMain.Location = new System.Drawing.Point(65, 29);
            this.txtMain.Name = "txtMain";
            this.txtMain.Size = new System.Drawing.Size(804, 34);
            this.txtMain.TabIndex = 44;
            this.txtMain.TabStop = false;
            // 
            // lblMain
            // 
            this.lblMain.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.lblMain.Font = new System.Drawing.Font("Courier New", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMain.Location = new System.Drawing.Point(65, 498);
            this.lblMain.Name = "lblMain";
            this.lblMain.Size = new System.Drawing.Size(804, 34);
            this.lblMain.TabIndex = 45;
            // 
            // frmTeletyperGibbens
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(919, 554);
            this.Controls.Add(this.lblMain);
            this.Controls.Add(this.txtMain);
            this.Controls.Add(this.btnLetterU);
            this.Controls.Add(this.btnLetterX);
            this.Controls.Add(this.btnLetterZ);
            this.Controls.Add(this.btnLetterW);
            this.Controls.Add(this.btnLetterV);
            this.Controls.Add(this.btnLetterY);
            this.Controls.Add(this.btnLetterT);
            this.Controls.Add(this.btnLetterF);
            this.Controls.Add(this.btnLetterE);
            this.Controls.Add(this.btnLetterA);
            this.Controls.Add(this.btnLetterB);
            this.Controls.Add(this.btnLetterC);
            this.Controls.Add(this.btnLetterQ);
            this.Controls.Add(this.btnLetterG);
            this.Controls.Add(this.btnLetterP);
            this.Controls.Add(this.btnLetterO);
            this.Controls.Add(this.btnLetterS);
            this.Controls.Add(this.btnLetterM);
            this.Controls.Add(this.btnLetterN);
            this.Controls.Add(this.btnLetterJ);
            this.Controls.Add(this.btnLetterI);
            this.Controls.Add(this.btnLetterH);
            this.Controls.Add(this.btnLetterL);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDigit7);
            this.Controls.Add(this.btnDigit8);
            this.Controls.Add(this.btnDigit9);
            this.Controls.Add(this.btnDigit1);
            this.Controls.Add(this.btnDigit2);
            this.Controls.Add(this.btnDigit3);
            this.Controls.Add(this.btnDigit4);
            this.Controls.Add(this.btnDigit5);
            this.Controls.Add(this.btnDigit6);
            this.Controls.Add(this.btnDigit0);
            this.Controls.Add(this.btnLetterR);
            this.Controls.Add(this.btnLetterD);
            this.Controls.Add(this.btnLetterK);
            this.Controls.Add(this.btnPeriod);
            this.Controls.Add(this.btnComma);
            this.Controls.Add(this.btnBlankSpace);
            this.Name = "frmTeletyperGibbens";
            this.Text = "Exam 1 Lab - Teletype Simulation v. 0925";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnBlankSpace;
        private System.Windows.Forms.Button btnComma;
        private System.Windows.Forms.Button btnPeriod;
        private System.Windows.Forms.Button btnLetterK;
        private System.Windows.Forms.Button btnLetterD;
        private System.Windows.Forms.Button btnLetterR;
        private System.Windows.Forms.Button btnDigit0;
        private System.Windows.Forms.Button btnDigit6;
        private System.Windows.Forms.Button btnDigit5;
        private System.Windows.Forms.Button btnDigit4;
        private System.Windows.Forms.Button btnDigit3;
        private System.Windows.Forms.Button btnDigit2;
        private System.Windows.Forms.Button btnDigit1;
        private System.Windows.Forms.Button btnDigit9;
        private System.Windows.Forms.Button btnDigit8;
        private System.Windows.Forms.Button btnDigit7;
        private System.Windows.Forms.Button btnLetterL;
        private System.Windows.Forms.Button btnLetterH;
        private System.Windows.Forms.Button btnLetterI;
        private System.Windows.Forms.Button btnLetterJ;
        private System.Windows.Forms.Button btnLetterN;
        private System.Windows.Forms.Button btnLetterM;
        private System.Windows.Forms.Button btnLetterS;
        private System.Windows.Forms.Button btnLetterO;
        private System.Windows.Forms.Button btnLetterP;
        private System.Windows.Forms.Button btnLetterG;
        private System.Windows.Forms.Button btnLetterQ;
        private System.Windows.Forms.Button btnLetterC;
        private System.Windows.Forms.Button btnLetterB;
        private System.Windows.Forms.Button btnLetterA;
        private System.Windows.Forms.Button btnLetterE;
        private System.Windows.Forms.Button btnLetterF;
        private System.Windows.Forms.Button btnLetterT;
        private System.Windows.Forms.Button btnLetterY;
        private System.Windows.Forms.Button btnLetterV;
        private System.Windows.Forms.Button btnLetterW;
        private System.Windows.Forms.Button btnLetterZ;
        private System.Windows.Forms.Button btnLetterX;
        private System.Windows.Forms.Button btnLetterU;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox txtMain;
        private System.Windows.Forms.Label lblMain;
    }
}