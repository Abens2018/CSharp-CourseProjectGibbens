﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* Name : Autumn Gibbens
 * Course : ITD 2343 – Object Oriented Programming with C#
 * Instructor: Mark L. Pranger
 * Due Date: September 29, 2025
 */

namespace Section1Lab_GibbensProject
{
    public partial class frmTeletyperGibbens : Form
    {
        public frmTeletyperGibbens()
        {
            InitializeComponent();
        }
        static void Main()
        {
            Application.Run(new frmTeletyperGibbens());
        }

        private void btnLetterA_Click(object sender, EventArgs e)
        {
            txtMain.Text += "A";
        }

        private void btnLetterB_Click(object sender, EventArgs e)
        {
            txtMain.Text += "B";
        }

        private void btnLetterC_Click(object sender, EventArgs e)
        {
            txtMain.Text += "C";
        }

        private void btnLetterD_Click(object sender, EventArgs e)
        {
            txtMain.Text += "D";
        }

        private void btnLetterE_Click(object sender, EventArgs e)
        {
            txtMain.Text += "E";
        }

        private void btnLetterF_Click(object sender, EventArgs e)
        {
            txtMain.Text += "F";
        }

        private void btnLetterG_Click(object sender, EventArgs e)
        {
            txtMain.Text += "G";
        }

        private void btnLetterH_Click(object sender, EventArgs e)
        {
            txtMain.Text += "H";
        }

        private void btnLetterI_Click(object sender, EventArgs e)
        {
            txtMain.Text += "I";
        }

        private void btnLetterJ_Click(object sender, EventArgs e)
        {
            txtMain.Text += "J";
        }

        private void btnLetterK_Click(object sender, EventArgs e)
        {
            txtMain.Text += "K";
        }

        private void btnLetterL_Click(object sender, EventArgs e)
        {
            txtMain.Text += "L";
        }

        private void btnLetterM_Click(object sender, EventArgs e)
        {
            txtMain.Text += "M";
        }

        private void btnLetterN_Click(object sender, EventArgs e)
        {
            txtMain.Text += "N";
        }

        private void btnLetterO_Click(object sender, EventArgs e)
        {
            txtMain.Text += "O";
        }

        private void btnLetterP_Click(object sender, EventArgs e)
        {
            txtMain.Text += "P";
        }

        private void btnLetterQ_Click(object sender, EventArgs e)
        {
            txtMain.Text += "Q";
        }

        private void btnLetterR_Click(object sender, EventArgs e)
        {
            txtMain.Text += "R";
        }

        private void btnLetterS_Click(object sender, EventArgs e)
        {
            txtMain.Text += "S";
        }

        private void btnLetterT_Click(object sender, EventArgs e)
        {
            txtMain.Text += "T";
        }

        private void btnLetterU_Click(object sender, EventArgs e)
        {
            txtMain.Text += "U";
        }

        private void btnLetterV_Click(object sender, EventArgs e)
        {
            txtMain.Text += "V";
        }

        private void btnLetterW_Click(object sender, EventArgs e)
        {
            txtMain.Text += "W";
        }

        private void btnLetterX_Click(object sender, EventArgs e)
        {
            txtMain.Text += "X";
        }

        private void btnLetterY_Click(object sender, EventArgs e)
        {
            txtMain.Text += "Y";
        }

        private void btnLetterZ_Click(object sender, EventArgs e)
        {
            txtMain.Text += "Z";
        }

        private void btnComma_Click(object sender, EventArgs e)
        {
            txtMain.Text += ",";
        }

        private void btnPeriod_Click(object sender, EventArgs e)
        {
            txtMain.Text += ".";
        }

        private void btnBlankSpace_Click(object sender, EventArgs e)
        {
            txtMain.Text += " ";
        }

        private void btnDigit0_Click(object sender, EventArgs e)
        {
            txtMain.Text += "0";
        }

        private void btnDigit1_Click(object sender, EventArgs e)
        {
            txtMain.Text += "1";
        }

        private void btnDigit2_Click(object sender, EventArgs e)
        {
            txtMain.Text += "2";
        }

        private void btnDigit3_Click(object sender, EventArgs e)
        {
            txtMain.Text += "3";
        }

        private void btnDigit4_Click(object sender, EventArgs e)
        {
            txtMain.Text += "4";
        }

        private void btnDigit5_Click(object sender, EventArgs e)
        {
            txtMain.Text += "5";
        }

        private void btnDigit6_Click(object sender, EventArgs e)
        {
            txtMain.Text += "6";
        }

        private void btnDigit7_Click(object sender, EventArgs e)
        {
            txtMain.Text += "7";
        }

        private void btnDigit8_Click(object sender, EventArgs e)
        {
            txtMain.Text += "8";
        }

        private void btnDigit9_Click(object sender, EventArgs e)
        {
            txtMain.Text += "9";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtMain.Text = " ";
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            lblMain.Text = txtMain.Text;
            txtMain.Text = " ";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
