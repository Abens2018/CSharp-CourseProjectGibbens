﻿namespace Sec3LabExam_Gibbens
{
    partial class frmCryptogram
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchInput = new System.Windows.Forms.RichTextBox();
            this.rchPlain = new System.Windows.Forms.RichTextBox();
            this.rchCipher = new System.Windows.Forms.RichTextBox();
            this.lblInput = new System.Windows.Forms.Label();
            this.lblPlain = new System.Windows.Forms.Label();
            this.lblCipher = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnConvert = new System.Windows.Forms.Button();
            this.rdoDecrypt = new System.Windows.Forms.RadioButton();
            this.rdoIncypt = new System.Windows.Forms.RadioButton();
            this.grpChoice = new System.Windows.Forms.GroupBox();
            this.grpChoice.SuspendLayout();
            this.SuspendLayout();
            // 
            // rchInput
            // 
            this.rchInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchInput.ForeColor = System.Drawing.Color.Navy;
            this.rchInput.Location = new System.Drawing.Point(157, 56);
            this.rchInput.Name = "rchInput";
            this.rchInput.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rchInput.Size = new System.Drawing.Size(261, 96);
            this.rchInput.TabIndex = 0;
            this.rchInput.Text = "";
            // 
            // rchPlain
            // 
            this.rchPlain.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchPlain.ForeColor = System.Drawing.Color.Navy;
            this.rchPlain.Location = new System.Drawing.Point(12, 217);
            this.rchPlain.Name = "rchPlain";
            this.rchPlain.ReadOnly = true;
            this.rchPlain.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rchPlain.Size = new System.Drawing.Size(261, 96);
            this.rchPlain.TabIndex = 2;
            this.rchPlain.TabStop = false;
            this.rchPlain.Text = "";
            // 
            // rchCipher
            // 
            this.rchCipher.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchCipher.ForeColor = System.Drawing.Color.Navy;
            this.rchCipher.Location = new System.Drawing.Point(308, 217);
            this.rchCipher.Name = "rchCipher";
            this.rchCipher.ReadOnly = true;
            this.rchCipher.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rchCipher.Size = new System.Drawing.Size(261, 96);
            this.rchCipher.TabIndex = 3;
            this.rchCipher.TabStop = false;
            this.rchCipher.Text = "";
            // 
            // lblInput
            // 
            this.lblInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInput.ForeColor = System.Drawing.Color.Navy;
            this.lblInput.Location = new System.Drawing.Point(232, 9);
            this.lblInput.Name = "lblInput";
            this.lblInput.Size = new System.Drawing.Size(113, 44);
            this.lblInput.TabIndex = 0;
            this.lblInput.Text = "Input Text";
            this.lblInput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPlain
            // 
            this.lblPlain.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlain.ForeColor = System.Drawing.Color.Navy;
            this.lblPlain.Location = new System.Drawing.Point(79, 170);
            this.lblPlain.Name = "lblPlain";
            this.lblPlain.Size = new System.Drawing.Size(113, 44);
            this.lblPlain.TabIndex = 4;
            this.lblPlain.Text = "Plain Text";
            this.lblPlain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCipher
            // 
            this.lblCipher.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCipher.ForeColor = System.Drawing.Color.Navy;
            this.lblCipher.Location = new System.Drawing.Point(365, 170);
            this.lblCipher.Name = "lblCipher";
            this.lblCipher.Size = new System.Drawing.Size(128, 44);
            this.lblCipher.TabIndex = 5;
            this.lblCipher.Text = "Cipher Text";
            this.lblCipher.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.AliceBlue;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.Navy;
            this.btnExit.Location = new System.Drawing.Point(12, 393);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(159, 65);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.AliceBlue;
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.Navy;
            this.btnReset.Location = new System.Drawing.Point(212, 393);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(159, 65);
            this.btnReset.TabIndex = 2;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnConvert
            // 
            this.btnConvert.BackColor = System.Drawing.Color.AliceBlue;
            this.btnConvert.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConvert.ForeColor = System.Drawing.Color.Navy;
            this.btnConvert.Location = new System.Drawing.Point(410, 393);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(159, 65);
            this.btnConvert.TabIndex = 1;
            this.btnConvert.Text = "&Convert";
            this.btnConvert.UseVisualStyleBackColor = false;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // rdoDecrypt
            // 
            this.rdoDecrypt.AutoSize = true;
            this.rdoDecrypt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoDecrypt.ForeColor = System.Drawing.Color.Navy;
            this.rdoDecrypt.Location = new System.Drawing.Point(80, 19);
            this.rdoDecrypt.Name = "rdoDecrypt";
            this.rdoDecrypt.Size = new System.Drawing.Size(100, 29);
            this.rdoDecrypt.TabIndex = 0;
            this.rdoDecrypt.Text = "Decrypt";
            this.rdoDecrypt.UseVisualStyleBackColor = true;
            // 
            // rdoIncypt
            // 
            this.rdoIncypt.AutoSize = true;
            this.rdoIncypt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoIncypt.ForeColor = System.Drawing.Color.Navy;
            this.rdoIncypt.Location = new System.Drawing.Point(390, 19);
            this.rdoIncypt.Name = "rdoIncypt";
            this.rdoIncypt.Size = new System.Drawing.Size(91, 29);
            this.rdoIncypt.TabIndex = 1;
            this.rdoIncypt.Text = "Incrypt";
            this.rdoIncypt.UseVisualStyleBackColor = true;
            // 
            // grpChoice
            // 
            this.grpChoice.Controls.Add(this.rdoIncypt);
            this.grpChoice.Controls.Add(this.rdoDecrypt);
            this.grpChoice.Location = new System.Drawing.Point(12, 319);
            this.grpChoice.Name = "grpChoice";
            this.grpChoice.Size = new System.Drawing.Size(557, 54);
            this.grpChoice.TabIndex = 6;
            this.grpChoice.TabStop = false;
            // 
            // frmCryptogram
            // 
            this.AcceptButton = this.btnConvert;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(581, 481);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.grpChoice);
            this.Controls.Add(this.lblCipher);
            this.Controls.Add(this.lblPlain);
            this.Controls.Add(this.rchCipher);
            this.Controls.Add(this.rchPlain);
            this.Controls.Add(this.rchInput);
            this.Controls.Add(this.lblInput);
            this.Name = "frmCryptogram";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cryptogram";
            this.grpChoice.ResumeLayout(false);
            this.grpChoice.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.RichTextBox rchInput;
        private System.Windows.Forms.RichTextBox rchPlain;
        private System.Windows.Forms.RichTextBox rchCipher;
        private System.Windows.Forms.Label lblInput;
        private System.Windows.Forms.Label lblPlain;
        private System.Windows.Forms.Label lblCipher;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.RadioButton rdoDecrypt;
        private System.Windows.Forms.RadioButton rdoIncypt;
        private System.Windows.Forms.GroupBox grpChoice;
    }
}