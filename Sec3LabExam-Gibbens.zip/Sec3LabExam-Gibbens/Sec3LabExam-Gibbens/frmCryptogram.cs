﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sec3LabExam_Gibbens
{
    public partial class frmCryptogram : Form
    {
        static void Main()
        {
            Application.Run(new frmCryptogram());
        }
        public frmCryptogram()
        {
            InitializeComponent();
            rdoIncypt.Checked = true;
        }

        ///Creates a counter to show how many times something was decrypted
        int counterPlane = 0;
        ///Creates a counter to show how many times something was incrypted
        int counterCipher = 0;
        private bool errorCheck (string text)
        {
            if (text == "")
            {
                string message = "You need to have text.";
                string caption = "Error";
                MessageBox.Show(message, caption);
                return false;
            }
            else { return true; }
        }

        private string incryptText (string text)
        {
            string convert = "";
            text = text.ToUpper();
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == 'A')
                {
                    convert += 'R';
                } 
                else if (text[i] == 'B')
                {
                    convert += 'S';
                }
                else if (text[i] == 'C')
                {
                    convert += 'N';
                }
                else if (text[i] == 'D')
                {
                    convert += 'E';
                }
                else if (text[i] == 'E')
                {
                    convert += 'P';
                }
                else if (text[i] == 'F')
                {
                    convert += 'H';
                }
                else if (text[i] == 'G')
                {
                    convert += 'C';
                }
                else if (text[i] == 'H')
                {
                    convert += 'A';
                }
                else if (text[i] == 'I')
                {
                    convert += 'T';
                }
                else if (text[i] == 'J')
                {
                    convert += 'I';
                }
                else if (text[i] == 'K')
                {
                    convert += 'M';
                }
                else if (text[i] == 'L')
                {
                    convert += 'G';
                }
                else if (text[i] == 'M')
                {
                    convert += 'L';
                }
                else if (text[i] == 'N')
                {
                    convert += 'X';
                }
                else if (text[i] == 'O')
                {
                    convert += 'W';
                }
                else if (text[i] == 'P')
                {
                    convert += 'V';
                }
                else if (text[i] == 'Q')
                {
                    convert += 'F';
                }
                else if (text[i] == 'R')
                {
                    convert += 'U';
                }
                else if (text[i] == 'S')
                {
                    convert += 'J';
                }
                else if (text[i] == 'T')
                {
                    convert += 'Z';
                }
                else if (text[i] == 'U')
                {
                    convert += 'K';
                }
                else if (text[i] == 'V')
                {
                    convert += 'O';
                }
                else if (text[i] == 'W')
                {
                    convert += 'B';
                }
                else if (text[i] == 'X')
                {
                    convert += 'Y';
                }
                else if (text[i] == 'Y')
                {
                    convert += 'D';
                }
                else if (text[i] == 'Z')
                {
                    convert += 'Q';
                }
                else
                {
                    convert += text[i];
                }
            }
                
            return convert;
        }

        private string decryptText(string text)
        {
            string convert = "";
            text = text.ToUpper();
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == 'A')
                {
                    convert += 'H';
                }
                else if (text[i] == 'B')
                {
                    convert += 'W';
                }
                else if (text[i] == 'C')
                {
                    convert += 'G';
                }
                else if (text[i] == 'D')
                {
                    convert += 'Y';
                }
                else if (text[i] == 'E')
                {
                    convert += 'D';
                }
                else if (text[i] == 'F')
                {
                    convert += 'Q';
                }
                else if (text[i] == 'G')
                {
                    convert += 'L';
                }
                else if (text[i] == 'H')
                {
                    convert += 'F';
                }
                else if (text[i] == 'I')
                {
                    convert += 'J';
                }
                else if (text[i] == 'J')
                {
                    convert += 'S';
                }
                else if (text[i] == 'K')
                {
                    convert += 'U';
                }
                else if (text[i] == 'L')
                {
                    convert += 'M';
                }
                else if (text[i] == 'M')
                {
                    convert += 'K';
                }
                else if (text[i] == 'N')
                {
                    convert += 'C';
                }
                else if (text[i] == 'O')
                {
                    convert += 'V';
                }
                else if (text[i] == 'P')
                {
                    convert += 'E';
                }
                else if (text[i] == 'Q')
                {
                    convert += 'Z';
                }
                else if (text[i] == 'R')
                {
                    convert += 'A';
                }
                else if (text[i] == 'S')
                {
                    convert += 'B';
                }
                else if (text[i] == 'T')
                {
                    convert += 'I';
                }
                else if (text[i] == 'U')
                {
                    convert += 'R';
                }
                else if (text[i] == 'V')
                {
                    convert += 'P';
                }
                else if (text[i] == 'W')
                {
                    convert += 'O';
                }
                else if (text[i] == 'X')
                {
                    convert += 'N';
                }
                else if (text[i] == 'Y')
                {
                    convert += 'X';
                }
                else if (text[i] == 'Z')
                {
                    convert += 'T';
                }
                else
                {
                    convert += text[i];
                }
            }

            return convert;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            string message = "You have incrypted " + counterCipher + 
                " messages and you have decypted " + counterPlane + " messages.";
            string caption = "Goodbye!";
            MessageBox.Show(message, caption);
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            rchInput.Text = "";
            rchCipher.Text = "";
            rchPlain.Text = "";
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            string workingText = rchInput.Text;

            bool noError = errorCheck(workingText);

            if (noError)
            {
                if (rdoIncypt.Checked) 
                {
                    string convertedText = incryptText(workingText);
                    rchCipher.Text = convertedText;
                    rchPlain.Text = workingText.ToUpper();
                    counterCipher++;
                }
                else if (rdoDecrypt.Checked)
                {
                    string convertedText = decryptText(workingText);
                    rchPlain.Text = convertedText;
                    rchCipher.Text = workingText.ToUpper();
                    counterPlane++;
                }
            }
            rchInput.Focus();
        }
    }
}
